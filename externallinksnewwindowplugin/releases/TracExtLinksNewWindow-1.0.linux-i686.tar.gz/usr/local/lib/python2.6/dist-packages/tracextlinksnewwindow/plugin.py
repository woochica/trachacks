""" Copyright (c) 2008-2009 Martin Scharrer <martin@scharrer-online.de>
    $Id: plugin.py 7027 2009-11-02 23:40:12Z martin_s $
    $URL: http://trac-hacks.org/svn/externallinksnewwindowplugin/0.11/tracextlinksnewwindow/plugin.py $

    This is Free Software under the GPL v3!
"""

__url__      = ur"$URL: http://trac-hacks.org/svn/externallinksnewwindowplugin/0.11/tracextlinksnewwindow/plugin.py $"[6:-2]
__author__   = ur"$Author: martin_s $"[9:-2]
__revision__ = int("0" + r"$Rev: 7027 $"[6:-2])
__date__     = r"$Date: 2009-11-02 23:40:12 +0000 (Mon, 02 Nov 2009) $"[7:-2]

from  trac.core        import  Component, implements
from  trac.web.api     import  IRequestFilter
from  trac.web.chrome  import  ITemplateProvider, add_stylesheet, add_script

class ExtLinksNewWindowPlugin(Component):
    """Opens external links in new window

       `$Id: plugin.py 7027 2009-11-02 23:40:12Z martin_s $`
    """
    implements ( IRequestFilter, ITemplateProvider )

    # ITemplateProvider#get_htdocs_dirs
    def get_htdocs_dirs(self):
        from pkg_resources import resource_filename
        return [('extlinksnewwindow', resource_filename(__name__, 'htdocs'))]

    # ITemplateProvider#get_templates_dirs
    def get_templates_dirs(self):
        return []


    # IRequestFilter#pre_process_request
    def pre_process_request(self, req, handler):
        return handler

    # IRequestFilter#post_process_request
    def post_process_request(self, req, template, data, content_type):
        add_script(req, 'extlinksnewwindow/extlinks.js')
        return (template, data, content_type)

