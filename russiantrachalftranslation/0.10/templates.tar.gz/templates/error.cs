<?cs include "header.cs"?>

<div id="ctxtnav" class="nav"></div>

<div id="content" class="error">

 <?cs if error.type == "TracError" ?>
  <h1><?cs var:error.title ?></h1>
  <p class="message"><?cs var:error.message ?></p>

 <?cs elif error.type == "internal" ?>
  <h1>Ой-ой-ой&hellip;</h1>
  <div class="message">
   <strong>Trac заметил внутреннюю ошибку:</strong>
   <pre><?cs var:error.message ?></pre>
  </div>
  <p>Если вы полагаете что это действительно должно работать и вы можете воспроизвести данную ошибку,
   вы должны решиться отправить эту проблему команде Trac.</p>
  <p>Отправляйтесь на <a href="<?cs var:trac.href.homepage ?>"><?cs
   var:trac.href.homepage ?></a> и создавайте новое обращение, где подробно опишите проблему и то,
   как ее воспроизвести. И не забудьте приложить Python traceback расположенный ниже.</p>

 <?cs /if ?>

 <p>
  <a href="<?cs var:trac.href.wiki ?>/TracGuide">TracGuide</a>
  &mdash; The Trac User and Administration Guide
 </p>
 <?cs if:error.traceback ?>
  <h4>Python Traceback</h4>
  <pre><?cs var:error.traceback ?></pre>
 <?cs /if ?>

</div>
<?cs include "footer.cs"?>
