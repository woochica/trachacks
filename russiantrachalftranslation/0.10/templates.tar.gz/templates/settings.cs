<?cs include "header.cs"?>
<?cs include "macros.cs"?>

<div id="ctxtnav" class="nav"></div>

<div id="content" class="settings">

 <h1>Настройки и управление сессиями</h1>

 <h2>Пользовательские настройки</h2>
 <p>
 Эта страница позволит вам управлять вашими настройками Trac.
 Настройки сессий хранятся на сервере и определяются с помощью 'Ключа сессии', сохраненного в cookies вашего браузера.
 Cookie позволяет Trac запомниать и восстанавливать ваши настройки.
 </p>
 <form method="post" action="">
 <div>
  <h3>Личная информация</h3>
  <div>
   <input type="hidden" name="action" value="save" />
   <label for="name">Имя:</label>
   <input type="text" id="name" name="name" class="textwidget" size="30"
          value="<?cs var:settings.name ?>" />
  </div>
  <div>
   <label for="email">Email:</label>
   <input type="text" id="email" name="email" class="textwidget" size="30"
          value="<?cs var:settings.email ?>" />
  </div><?cs
  if:settings.session_id ?>
   <h3>Сессия</h3>
   <div>
    <label for="newsid">Ключ сессии:</label>
    <input type="text" id="newsid" name="newsid" class="textwidget" size="30"
           value="<?cs var:settings.session_id ?>" />
    <p>
    Ключ сессии используется для идентификации пользовательских настроек и сессий, хранящихся на сервере.
    Ключ по умолчанию генерируется автоматически, но вы можете сменить его на что нибудь более легкое для запоминания, 
    для того, чтобы иметь возможность использовать свои настройки в любое время и из любого браузера.</p>
   </div><?cs
  /if ?>
  <div>
   <br />
   <input type="submit" value="Сохранить изменения" />
  </div >
 </div>
</form><?cs
if:settings.session_id ?>
 <hr />
 <h2>Загрузка сессии</h2>
 <p>
 Вы можете загрузить предварительно созданную сессию, если введете соответствующий ключ в специальном поле, 
 расположенном после этого абзаца, и нажмете кнопку "Восстановить". Это позволит вам использовать ваши настройки на различных
 компьютерах и браузерах.</p>
 <form method="post" action="">
  <div>
   <input type="hidden" name="action" value="load" />
   <label for="loadsid">Existing Session Key:</label>
   <input type="text" id="loadsid" name="loadsid" class="textwidget" size="30"
          value="" />
   <input type="submit" value="Восстановить" />
  </div>
 </form><?cs
/if ?>

</div>
<?cs include:"footer.cs"?>
