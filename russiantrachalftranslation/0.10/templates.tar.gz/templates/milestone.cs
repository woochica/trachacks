<?cs include:"header.cs"?>
<?cs include:"macros.cs"?>

<div id="ctxtnav" class="nav"></div>

<div id="content" class="milestone">
 <?cs if:milestone.mode == "new" ?>
 <h1>Новый этап</h1>
 <?cs elif:milestone.mode == "edit" ?>
 <h1>Редактировать этап <?cs var:milestone.name ?></h1>
 <?cs elif:milestone.mode == "delete" ?>
 <h1>Удалить этап <?cs var:milestone.name ?></h1>
 <?cs else ?>
 <h1>Этап <?cs var:milestone.name ?></h1>
 <?cs /if ?>

 <?cs if:milestone.mode == "edit" || milestone.mode == "new" ?>
  <script type="text/javascript">
    addEvent(window, 'load', function() {
      document.getElementById('name').focus();
    });
  </script>
  <form id="edit" action="<?cs var:milestone.href ?>" method="post">
   <input type="hidden" name="id" value="<?cs var:milestone.name ?>" />
   <input type="hidden" name="action" value="edit" />
   <div class="field">
    <label>Название этапа:<br />
    <input type="text" id="name" name="name" size="32" value="<?cs
      var:milestone.name ?>" /></label>
   </div>
   <fieldset>
    <legend>Планирование</legend>
    <label>Завершить до:<br />
     <input type="text" id="duedate" name="duedate" size="<?cs
       var:len(milestone.date_hint) ?>" value="<?cs
       var:milestone.due_date ?>" title="Формат: <?cs var:milestone.date_hint ?>" />
     <em>Формат: <?cs var:milestone.date_hint ?></em>
    </label>
    <div class="field">
     <label>
      <input type="checkbox" id="completed" name="completed"<?cs
        if:milestone.completed ?> checked="checked"<?cs /if ?> />
      Завершен:<br />
     </label>
     <label>
      <input type="text" id="completeddate" name="completeddate" size="<?cs
        var:len(milestone.date_hint) ?>" value="<?cs
        alt:milestone.completed_date ?><?cs
         var:milestone.datetime_now ?><?cs
        /alt ?>" title="Формат: <?cs
        var:milestone.datetime_hint ?>" />
      <em>Формат: <?cs var:milestone.datetime_hint ?></em>
     </label><?cs
     if:len(milestones) ?>
     <br/>
     <input type="checkbox" id="retarget" name="retarget" checked="checked"
            onclick="enableControl('target', this.checked)"/>
     <label>
      Перенаправить открытые обращения, ассоциированые с этим этапом на
      <select id="target" name="target">
       <option value="">этап не выбран</option><?cs
       each:name = milestones ?>
       <option><?cs var:name ?></option><?cs
       /each ?>
      </select>
     </label><?cs
     /if ?>
     <script type="text/javascript">
       var completed = document.getElementById("completed");
       var retarget = document.getElementById("retarget");
       var enableCompletedDate = function() {
         enableControl("completeddate", completed.checked);
         enableControl("retarget", completed.checked);
         enableControl("target", completed.checked && retarget.checked);
       };
       addEvent(window, "load", enableCompletedDate);
       addEvent(completed, "click", enableCompletedDate);
     </script>
    </div>
   </fieldset>
   <div class="field">
    <fieldset class="iefix">
     <label for="description">Описание (вы можете использовать здесь <a tabindex="42" href="<?cs
       var:trac.href.wiki ?>/WikiFormatting">Вики-форматирование</a>):</label>
     <p><textarea id="description" name="description" class="wikitext" rows="10" cols="78">
<?cs var:milestone.description_source ?></textarea></p>
    </fieldset>
   </div>
   <div class="buttons">
    <?cs if:milestone.mode == "new"
     ?><input type="submit" value="Добавить этап" /><?cs
    else
     ?><input type="submit" value="Сохранить изменения" /><?cs
    /if ?>
    <input type="submit" name="cancel" value="Отмена" />
   </div>
   <script type="text/javascript" src="<?cs
     var:htdocs_location ?>js/wikitoolbar.js"></script>
  </form>
 <?cs elif:milestone.mode == "delete" ?>
  <form action="<?cs var:milestone.href ?>" method="post">
   <input type="hidden" name="id" value="<?cs var:milestone.name ?>" />
   <input type="hidden" name="action" value="delete" />
   <p><strong>Вы уверены что хотите удалить этот этап?</strong></p>
   <input type="checkbox" id="retarget" name="retarget" checked="checked"
       onclick="enableControl('target', this.checked)"/>
   <label for="target">Перенаправить открытые обращения ассоциированные с этим этапом на</label>
   <select name="target" id="target">
    <option value="">None</option><?cs
     each:other = milestones ?><?cs if:other != milestone.name ?>
      <option><?cs var:other ?></option><?cs 
     /if ?><?cs /each ?>
   </select>
   <div class="buttons">
    <input type="submit" name="cancel" value="Отменыа" />
    <input type="submit" value="Удалить этап" />
   </div>
  </form>
 <?cs else ?>
 <?cs if:milestone.mode == "view" ?>
  <div class="info">
   <p class="date"><?cs
    if:milestone.completed_date ?>
     Завершен <?cs var:milestone.completed_delta ?> назад (<?cs var:milestone.completed_date ?>)<?cs
    elif:milestone.due_date ?><?cs
     if:milestone.late ?>
      <strong>Задержка на <?cs var:milestone.due_delta ?></strong><?cs
     else ?>
      В течение <?cs var:milestone.due_delta ?><?cs
     /if ?> (<?cs var:milestone.due_date ?>)<?cs
    else ?>
     Дата не указана<?cs
    /if ?>
   </p><?cs
   with:stats = milestone.stats ?><?cs
    if:#stats.total_tickets > #0 ?>
     <table class="progress">
      <tr>
      <td class="closed" style="width: <?cs
        var:#stats.percent_closed ?>%">
        <a href="<?cs
        var:milestone.queries.closed_tickets ?>" title="<?cs
        var:#stats.closed_tickets ?> из <?cs
        var:#stats.total_tickets ?> закрыто"></a></td>
      <td class="open" style="width: <?cs
        var:#stats.percent_active ?>%">
        <a href="<?cs
        var:milestone.queries.active_tickets ?>" title="<?cs
        var:#stats.active_tickets ?> из <?cs
        var:#stats.total_tickets ?> активно"></a>
      </tr>
     </table>
     <p class="percent"><?cs var:#stats.percent_closed ?>%</p>
     <dl>
      <dt>Закрытые обращения:</dt>
      <dd><a href="<?cs var:milestone.queries.closed_tickets ?>"><?cs
        var:stats.closed_tickets ?></a></dd>
      <dt>Активные обращения:</dt>
      <dd><a href="<?cs var:milestone.queries.active_tickets ?>"><?cs
        var:stats.active_tickets ?></a></dd>
     </dl><?cs
    /if ?><?cs
   /with ?>
  </div>
  <form id="stats" action="" method="get">
   <fieldset>
    <legend>
     <label for="by">Статус обращения по</label>
     <select id="by" name="by" onchange="this.form.submit()"><?cs
     each:group = milestone.stats.available_groups ?>
      <option value="<?cs var:group.name ?>" <?cs
        if:milestone.stats.grouped_by == group.name ?> selected="selected"<?cs
        /if ?>><?cs call:russ(group.label) ?></option><?cs
     /each ?></select>
     <noscript><input type="submit" value="Обновить" /></noscript>
    </legend>
    <table summary="Показывать данные о завершенности этапа сгруппированные по <?cs
      var:milestone.stats.grouped_by ?>"><?cs
     each:group = milestone.stats.groups ?>
      <tr>
       <th scope="row"><a href="<?cs
         var:group.queries.all_tickets ?>"><?cs var:group.name ?></a></th>
       <td style="white-space: nowrap"><?cs if:#group.total_tickets ?>
        <table class="progress" style="width: <?cs
          var:#group.percent_total * #80 / #milestone.stats.max_percent_total ?>%">
         <tr>
          <td class="closed" style="width: <?cs
            var:#group.percent_closed ?>%"><a href="<?cs
            var:group.queries.closed_tickets ?>" title="<?cs
           var:group.closed_tickets ?> из <?cs
           var:group.total_tickets ?> активно"></a>
          </td>
          <td class="open" style="width: <?cs
            var:#group.percent_active ?>%"><a href="<?cs
            var:group.queries.active_tickets ?>" title="<?cs
           var:group.active_tickets ?> из <?cs
           var:group.total_tickets ?> активно"></a>
          </td>
         </tr>
        </table>
        <p class="percent"><?cs var:group.closed_tickets ?>/<?cs
         var:group.total_tickets ?></p>
       <?cs /if ?></td>
      </tr><?cs
     /each ?>
    </table><?cs /if ?>
   </fieldset>
  </form>
  <div class="description"><?cs var:milestone.description ?></div><?cs
  if:trac.acl.MILESTONE_MODIFY || trac.acl.MILESTONE_DELETE ?>
   <div class="buttons"><?cs
    if:trac.acl.MILESTONE_MODIFY ?>
     <form method="get" action=""><div>
      <input type="hidden" name="action" value="edit" /><?cs
      if:milestone.id_param ?>
       <input type="hidden" name="id" value="<?cs var:milestone.name ?>" /><?cs
      /if ?>
      <input type="submit" value="Редактировать информацию об этапе" accesskey="e" />
     </div></form><?cs
    /if ?><?cs
    if:trac.acl.MILESTONE_DELETE ?>
     <form method="get" action=""><div>
      <input type="hidden" name="action" value="delete" /><?cs
      if:milestone.id_param ?>
       <input type="hidden" name="id" value="<?cs var:milestone.name ?>" /><?cs
      /if ?>
      <input type="submit" value="Удалить этап" />
     </div></form><?cs
    /if ?>
   </div><?cs
  /if ?><?cs
 /if ?>

 <div id="help">
  <strong>Примечание:</strong> обратитесь к <a href="<?cs
    var:trac.href.wiki ?>/TracRoadmap">странице графика работ</a> для получения помощи.
 </div>

</div>
<?cs include:"footer.cs"?>
